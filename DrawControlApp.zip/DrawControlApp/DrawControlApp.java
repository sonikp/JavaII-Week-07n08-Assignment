// DrawControlApp.java
import java.awt.Color;
import javax.swing.JFrame;

public class DrawControlApp
{
   public static void main( String args[] )
   {
      JFrame frame = new ControlFrame( "Controlling Multimedia Projects..." );
   }
}
